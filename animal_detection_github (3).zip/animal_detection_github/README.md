# Animal Detection AI

A simple Gradio website for classifying animal photos into five classes: Cats, Dogs, Elephants, Lions, and Tigers.

## Files
- `app.py` — website code
- `requirements.txt` — Python dependencies
- `animal_model.keras` — your trained model file; you must obtain it from your Kaggle notebook output and add it here

## Important
This app assumes the model accepts 224 × 224 RGB images and outputs class scores in this exact order: Cats, Dogs, Elephants, Lions, Tigers. Image preprocessing must match your Kaggle training code. If you divided image pixels by 255 during training, uncomment the corresponding line in `app.py`.

## Run
1. Put `animal_model.keras` in the same folder as `app.py`.
2. Install dependencies with `pip install -r requirements.txt`.
3. Run `python app.py`.

## Publish online
Create a Gradio Space on Hugging Face and upload `app.py`, `requirements.txt`, `README.md`, and the trained model file if its size and platform limits permit. Then share the Space's public URL.

A 100% score on a tiny test set does not guarantee accurate predictions on new photos.
