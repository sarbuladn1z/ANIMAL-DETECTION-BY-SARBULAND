import os
import gradio as gr
import tensorflow as tf
import numpy as np
from PIL import Image

MODEL_PATH = "animal_model.keras"
CLASS_NAMES = ["Cats", "Dogs", "Elephants", "Lions", "Tigers"]

_model = None

def get_model():
    global _model
    if _model is None:
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(
                "animal_model.keras not found. Add your trained model file "
                "to this folder before running the website."
            )
        _model = tf.keras.models.load_model(MODEL_PATH)
    return _model

def predict_animal(image):
    if image is None:
        return {"Please upload an image": 1.0}

    model = get_model()
    image = image.convert("RGB").resize((224, 224))
    arr = np.asarray(image, dtype=np.float32)
    arr = np.expand_dims(arr, axis=0)

    # If your training code divided image pixels by 255, uncomment this line:
    # arr = arr / 255.0

    scores = model.predict(arr, verbose=0)[0]
    if len(scores) != len(CLASS_NAMES):
        raise ValueError("Model output classes do not match the five class names.")
    return {CLASS_NAMES[i]: float(scores[i]) for i in range(len(CLASS_NAMES))}

app = gr.Interface(
    fn=predict_animal,
    inputs=gr.Image(type="pil", label="Upload Animal Photo"),
    outputs=gr.Label(num_top_classes=5, label="AI Prediction"),
    title="Animal Detection AI",
    description="Upload a photo to predict whether it is a cat, dog, elephant, lion, or tiger.",
)

if __name__ == "__main__":
    app.launch()
